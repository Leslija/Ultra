discord = {
    ['webhook'] = 'https://discord.com/api/webhooks/973618164350980136/MW0AmWVo17I2FqiuPpxxShBlRS7fLOeFIS2mDdBfkXCNWW0HavVVcvfIy6b4tUECjSWD',
    ['name'] = 'SAFKY Territories',
    ['image'] = 'https://cdn.discordapp.com/attachments/950839829116117012/951859639048351775/myLogo.png'
}
