# SAFKY TERRITORIES (ESX/QBCORE)
- The ultimate territories system! 
Let gangs fight for territories and win the rewards you want by winning it!
When winning the territory, gang players will be able to acess the stash and remove the money inside!
Configurable automatic reward system by time, to increase the value of each stash!
Selling Drugs system option, with configurable percentage to the assign territory! Let players sell on your territory and win a percentage of that!
- Configurable Job Required to control a territory!
- Eye-Target Compatible!
- Configurable Global Blips Alerts!
- Translation of everything available!
- Configurable Territories (add as many as you wish).
- You can enable the sales of drugs and configure it to each territory, and what percentage the territory win!
- Configurable payments types.
- Enable the increase automatic of the money inside each stash and configure the amount and time!
- Logs of every move! 


__PREVIEW__
[(https://youtu.be/_Ive5JJEcVA)]

## Instalation:
```
1) Run the SQL
2) Put `ensure s_territories` to your start config and resource called `s_territories` into your resources folder
3) Configure config/config.lua 
4) Configure translations.lua
5) Discord Logs - server/webhook.lua
```

## Requierements ESX
- ESX
- s_menu [(https://github.com/paulosafky/s_menu)]
- s_keyboard [(https://github.com/paulosafky/s_keyboard)]
- s_target (optional)

## Requierements QBCORE
- QBCORE
- The script uses qb-menu, qb-input and qb-target exports.

## SAFKY Discord
https://discord.gg/Rcth7Avbkm

