--████████╗██████╗░░█████╗░███╗░░██╗░██████╗██╗░░░░░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗
--╚══██╔══╝██╔══██╗██╔══██╗████╗░██║██╔════╝██║░░░░░██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝
--░░░██║░░░██████╔╝███████║██╔██╗██║╚█████╗░██║░░░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░
--░░░██║░░░██╔══██╗██╔══██║██║╚████║░╚═══██╗██║░░░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗
--░░░██║░░░██║░░██║██║░░██║██║░╚███║██████╔╝███████╗██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝
--░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░

Translations = {
    ['server_name'] = 'Your Server Name Here',
    ['territory'] = 'Territory: ',
	['stash'] = 'Stash',
    ['open_stash'] = 'Open Stash',
    ['control'] = 'Control Territory',
    ['control_text'] = 'Can you make it true?',
    ['selldrugs'] = 'Sell Drugs',
    ['sell'] = 'Sell',
    ['for'] = 'for',
    ['dont_have'] = 'You dont have enought to sell!',
    ['no_weapon'] = 'You need a weapon to control a territory!',
    ['start_atempt'] = 'You start to atempt controling',
    ['time_needed'] = ' Time left',
    ['minutes'] = 'minutes.',
    ['control_failed'] = 'The atempt to control the territory has failed!',
    ['canceled'] = 'Canceled',
    ['success_control'] = 'You controled the territory with sucess!',
    ['invalid_amount'] = 'Invalid amount!',
    ['permissions'] = 'You dont have permission!',
    ['balance'] = 'Balance: ',
    ['amount'] = 'Amount',
    ['already_owned'] = 'You already own this territory!',
    ['max_territories'] = 'Your organization have the maximum territories allowed!',
    ['already_attempt'] = 'Someone is already attempting to control this territory at the moment!',
    ['attempt_started'] = 'An attempt was started to try to control the: ',
    ['failed_attempt'] = 'The control attempt failed at: ',
    ['success_attempt'] = ' was successfully controlled!',
    ['selling'] = 'Selling Drugs', 
}
